This is the binary distribution of Slash'EM 0.0.7E7F2 for Mac OS Classic. This is a Power PC binary, so it will run only on a Macintosh with a Power PC processor.

This package is freely distributable; see the file 'License' for details.

Read the Guidebook for a general description of what Slash'EM is and how to play. Unfortunately, the Guidebook is > 32K, so you will need something other than SimpleText to view it. Edit the file Slash'EM Defaults in this directory to modify startup options. Feel free to turn off News when you get tired of seeing its message when you start up.