/*   SCCS Id: @(#)ntsound.c   3.2     95/09/06                        */
/*   Copyright (c) NetHack PC Development Team 1993                 */
/*   NetHack may be freely redistributed.  See license for details. */
/*                                                                  */
/*
 * ntsound.c - Windows NT NetHack sound support
 *                                                  
 *Edit History:
 *     Initial Creation                              93/12/11
 *
 */

#include "hack.h"

/* ntsound.c */
