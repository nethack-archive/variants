/* For use with MPW */
#pragma load ":Obj:hack.hdump"
