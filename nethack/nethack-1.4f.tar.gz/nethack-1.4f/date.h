/*	SCCS Id: @(#)date.h	1.3	87/07/14 */

char datestring[] = "Fri Jun 26 11:49:16 1987";
