/*	SCCS Id: @(#)osbind.h	3.0	88/07/22
/* Copyright (c) Stichting Mathematisch Centrum, Amsterdam, 1985. */
/* NetHack may be freely redistributed.  See license for details. */

#ifndef OSBIND_H
#define OSBIND_H

#endif /* OSBIND_H */
