#ifndef SIGNAL_H
#define SIGNAL_H

#define SIG_IGN     1
#define SIG_DFL     0
#define signal(x,y) SIG_IGN

#endif
