/*	SCCS Id: @(#)date.h	1.4	87/08/08 */

char datestring[] = "Mon Nov 30 01:25:12 1987";
