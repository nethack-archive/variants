#! /bin/csh -f
foreach i (NetHack.??)
unshar $i
end
